local config = {}


config.inVMD = 'VMD\\EPIC_ADT_2019.vmd'
config.outVMD = 'VMD\\HL7_ADT_2_7.vmd'
config.messageType = 'ADT'
config.useGeneralMapping = true --true or false
config.useCodeMap = true --true or false

return config
